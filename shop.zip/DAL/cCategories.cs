﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public partial class Categories
    {
        public static List<Category> getAllCategoryies()
        {
            return new shopDataContext().Categories.ToList();
        }
        public static List<Category> searchCategorybyTitle(string pKeyword)
        {
            return new shopDataContext().Categories.Where(i=>i.Title.Contains(pKeyword)).ToList();
            //ToList();
        }
        public static bool insert(Category objCategory)
        {
            try
            {
                var db = new shopDataContext();
                db.Categories.InsertOnSubmit(objCategory);
                db.SubmitChanges();
                if (objCategory.Id > 0)
                    return true;
                else
                    return false;
            }
            catch (Exception)
            {
                return false;
                //
                throw;
            }


        }
    }
}
