﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAL;

namespace Web
{
    public partial class insertCategory : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                fillCategoryGrid();
                filldrpCategories();
            }

        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            Category objCategory = new Category();

            objCategory.Title = txtTitle.Text;
            objCategory.ParentId = int.Parse(drpCategories.SelectedValue.ToString());
            //objCategory.ParentId=???
            if (Categories.insert(objCategory))
            {
                lblMSG.Text = "OK";
                fillCategoryGrid();
                filldrpCategories();
            }
            else
                lblMSG.Text = "Error";
             ;
            
        }
        private void fillCategoryGrid()
        {
            CategoryGrid.DataSource = Categories.getAllCategoryies();
            CategoryGrid.DataBind();
        }
        private void filldrpCategories()
        {
            drpCategories.DataSource = Categories.getAllCategoryies();
            drpCategories.DataBind();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            CategoryGrid.DataSource = Categories.searchCategorybyTitle(txtTitle.Text);
            CategoryGrid.DataBind();
        }
    }
}